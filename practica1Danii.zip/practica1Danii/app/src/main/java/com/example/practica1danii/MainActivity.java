package com.example.practica1danii;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Spinner spinner = (Spinner) findViewById(R.id.frutas);

        final String[] fruta = {"Melon", "Fresa", "Mango", "Uva", "Pera"};
        final ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, fruta);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {


            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long i) {
                Toast.makeText(getApplicationContext(), "El elemento seleccionado es:" + adapterView.getItemAtPosition(position), Toast.LENGTH_LONG).show();
            }


            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });

    }

}